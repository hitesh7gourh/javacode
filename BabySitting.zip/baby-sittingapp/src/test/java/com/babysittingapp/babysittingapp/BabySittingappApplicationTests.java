package com.babysittingapp.babysittingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabySittingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
