package word_Creation;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Test;

class MainTest {

	@Test
	void test() {
		
		Main a = new Main();
		String fileName = "C:/Users/839115/Documents/CaseStudy1/Trexo_CaseStudy";
        String outputFilename="C:/Users/839115/Documents/CaseStudy1/Trexo_FinalResult.docx";
        String extension = fileName.substring(fileName.lastIndexOf('.') + 1);

        SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");  
        Date date = new Date();  
        String newFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "_" + formatter.format(date) + "." + extension;
        
        XWPFDocument document = new XWPFDocument();

        File f = new File(fileName);
        File f1 =new File(newFileName);
        
        assertEquals("y", a.Result( fileName, outputFilename,
        		      extension,  formatter,
        		      f,  f1,  newFileName,   document,  date));
        
	}

}
