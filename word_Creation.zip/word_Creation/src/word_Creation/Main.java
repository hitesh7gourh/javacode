package word_Creation;
 
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
 
public class Main{
 
    public static void main(String[] args) {
 
    	Main a = new Main();
    	
        String fileName = "C:/Users/839115/Documents/CaseStudy1/Trexo_CaseStudy";
        String outputFilename="C:/Users/839115/Documents/CaseStudy1/Trexo_FinalResult.docx";
        String extension = fileName.substring(fileName.lastIndexOf('.') + 1);

        SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");  
        Date date = new Date();  
        String newFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "_" + formatter.format(date) + "." + extension;
        
        XWPFDocument document = new XWPFDocument();

        File f = new File(fileName);
        File f1 =new File(newFileName);
        
        a.Result( fileName, outputFilename,
        		 extension,  formatter,
        		 f,  f1,  newFileName,   document,  date);
       
    }
    
    //other
    public String Result(String fileName,String outputFilename,
    		String extension, SimpleDateFormat formatter,
    		File f, File f1, String newFileName,  XWPFDocument document, Date date) {
    	
    	String s = " ";
    	 if(f.renameTo(f1)) {
    	        
 		    if (f1.exists()) {
 		    	
 		        if (extension.equals("txt")){
 		        	if(newFileName.substring(newFileName.lastIndexOf("_")+1,newFileName.lastIndexOf(".")).equals(formatter.format(date))){
 		            		 s = convert( f,  f1,  newFileName,  formatter,  date,  document,  outputFilename);
 		            		
 		        	}
 		        	else{
 		        		 s = "Error Message: Current Date not appended in the txt file ";
 		        		
 		        		}
 		        } else {
 		             s = "a";
 		         
 		            }
 		 
         } else {
              s = "Error Message: File is missing in the path ";
          
  
         }
         }
    	 
    	 return s;
    	 
    }

    
    
    
    
    
    
    
    
    //docu.............
    
    
    public static String convert(File f, File f1, String newFileName, SimpleDateFormat formatter, Date date, XWPFDocument document, String outputFilename) {
    try {
		 
		BufferedReader br = new BufferedReader(new FileReader(f1));
		FileOutputStream out = new FileOutputStream(new File(outputFilename.substring(0, outputFilename.lastIndexOf(".")) + "_" + formatter.format(date) + "." + "docx"));

	String line;
	while ((line = br.readLine()) != null) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun line1 = paragraph.createRun();
		line1.setText(line);
	}
	document.write(out);

	} catch (IOException exception) {
		exception.printStackTrace();
	}
    
    String s = " ";
    
    if(document != null) {
     s = "y";
    }else {
    	 s = "n";
    }
    
    return s;
    }
}